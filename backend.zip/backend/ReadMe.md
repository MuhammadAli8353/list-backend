# To-Do List API (Backend)

This is a simple backend API for a to-do list application built with Node.js and Express.js. 

## API Endpoints:
- `POST /addTask`: Add a new task.
- `GET /tasks`: Get all tasks.
- `DELETE /task/:id`: Delete a task by its ID.

## How to run:
1. Install dependencies: `npm install`
2. Start the server: `node index.js`
3. Test the API using Postman.
