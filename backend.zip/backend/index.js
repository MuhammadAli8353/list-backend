const express = require('express');
const app = express();
const port = 3000;

// Middleware to parse JSON
app.use(express.json());

// In-memory data storage
let tasks = [];
let idCounter = 1;

// POST /addTask → Add new task
app.post('/addTask', (req, res) => {
    const { taskName } = req.body;
    if (!taskName) {
        return res.status(400).json({ error: 'taskName is required' });
    }

    const newTask = { id: idCounter++, taskName };
    tasks.push(newTask);
    res.status(201).json(newTask);
});

// GET /tasks → View all tasks
app.get('/tasks', (req, res) => {
    res.json(tasks);
});

// DELETE /task/:id → Delete task by ID
app.delete('/task/:id', (req, res) => {
    const id = parseInt(req.params.id);
    const index = tasks.findIndex(task => task.id === id);

    if (index === -1) {
        return res.status(404).json({ error: 'Task not found' });
    }

    const deletedTask = tasks.splice(index, 1);
    res.json({ message: 'Task deleted', task: deletedTask[0] });
});

// Start the server
app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});
